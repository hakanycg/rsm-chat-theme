# gungame-chat

Just a simple chat theme used on the Gun Game server on the FiveM platform.

This changes some simple colors, the size of the chat box, and font. Perhaps some more