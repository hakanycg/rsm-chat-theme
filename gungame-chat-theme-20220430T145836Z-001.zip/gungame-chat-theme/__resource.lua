file 'style.css'
file 'config.js'

chat_theme 'gungame' {
    styleSheet = 'style.css',
    msgTemplates = {
        default = '<b>{0}</b> <span>{1}</span>'
    },
}